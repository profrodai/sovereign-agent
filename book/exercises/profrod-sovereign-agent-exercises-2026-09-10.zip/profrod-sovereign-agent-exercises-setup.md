# Set up before the session

> **Learn with Prof Rod** — *Build Your Always-On AI Agent From Scratch*.
> **Read the full book and get the latest learning materials:** [https://profrod.ai/book](https://profrod.ai/book).
> **Join the Prof Rod learner community:** [https://profrod.ai/community](https://profrod.ai/community)
> — bring your questions, compare experiments and share what you build.
> **Original source and updates:** [profrodai/sovereign-agent](https://github.com/profrodai/sovereign-agent).

The fastest path is **Google Colab**: every exercise notebook carries an *Open in Colab* badge under its title, and Colab's interpreter (Python 3.12 today) runs the whole lesson with no installation. Locally, use Python 3.12 or newer and a Jupyter kernel that selects that interpreter; an older kernel fails at the setup cell before the lesson begins. Basic functions, loops, lists and dictionaries are prerequisites. Pydantic, SQLite and specialized concepts are introduced inside each unit before use.

Each unit closes with an optional extension that puts a language model behind the chapter's own tools. It replays a recorded transcript by default. To run it live, add a secret named `OPENAI_API_KEY` in Colab's Secrets pane (the key icon in the left sidebar) and switch on notebook access for it, or export that variable before starting a local kernel and run `%pip install openai` once. The notebooks never print the key.

If you already have Jupyter, select a Python 3.12 or newer kernel. Install the exact Pydantic version in that kernel once:

```python
%pip install "pydantic==2.13.4"
```

Restart the kernel after installation. Package installation requires internet; the core lessons run offline without model credentials, a Telegram account or a supplier account. A notebook includes its own frozen teaching runtime and writes scratch files into a temporary directory. Keep your edited notebook and saved handoff/evidence files outside scratch cleanup.

## Prepare this download on a new machine

A **virtual environment** keeps the course's Python packages separate from other projects. **JupyterLab** is the browser interface in which you open a notebook; **ipykernel** is the Python process that runs its cells. **uv** creates the environment and installs its packages. These tools are environment preparation, not concepts you need to derive to complete the agent exercises.

Install uv using its [official installation instructions](https://docs.astral.sh/uv/getting-started/installation/), then open a new terminal and check `uv --version`. Extract this asset's ZIP into a writable folder. Open a terminal **in that extracted folder**, beside this setup guide. No repository clone or other teaching asset is needed.

On macOS or Linux:

```bash
uv venv --python 3.12 --seed .venv
uv pip install --python .venv/bin/python "jupyterlab==4.6.3" "ipykernel==7.3.0" "pydantic==2.13.4"
.venv/bin/python -m jupyterlab
```

On Windows PowerShell:

```powershell
uv venv --python 3.12 --seed .venv
uv pip install --python .venv/Scripts/python.exe "jupyterlab==4.6.3" "ipykernel==7.3.0" "pydantic==2.13.4"
.venv/Scripts/python.exe -m jupyterlab
```

The first command obtains Python 3.12 if necessary and creates `.venv`; `--seed` supplies pip for notebook `%pip` commands. The second installs the notebook interface, kernel and lesson dependency. The third starts JupyterLab using this environment's Python. Keep the terminal open while working. JupyterLab opens a local browser page; if it does not, use the local URL printed by the command. Do not share that session URL.

In JupyterLab's file browser open the selected chapter folder and its descriptively named A notebook, such as `profrod-sovereign-agent-ch02-a-pydantic-shop-tools-exercise.ipynb`. Educators choose the local `student` or `solutions` folder. The filename identifies the chapter, topic, practice letter and exercise/solution role. Select its Python 3 kernel, then run this cell to verify which interpreter is actually running:

```python
import sys
import pydantic

print(sys.executable)
print(sys.version)
print(pydantic.__version__)
assert sys.version_info[:2] >= (3, 12)
assert pydantic.__version__ == "2.13.4"
```

Expect the executable inside your extracted asset's `.venv`, Python 3.12 or newer and Pydantic 2.13.4. If the assertions fail, select the local environment kernel before beginning; reinstalling packages into an unrelated terminal interpreter will not fix a wrong kernel. Save with Ctrl+S or Command+S. Stop the server with Ctrl+C in its terminal when finished.

These commands follow the official [environment](https://docs.astral.sh/uv/pip/environments/), [JupyterLab installation](https://jupyterlab.readthedocs.io/en/stable/getting_started/installation.html) and [startup](https://jupyterlab.readthedocs.io/en/stable/getting_started/starting.html) documentation. The package set resolved for Python 3.12 and 3.14 during preparation. This migration's notebook checks execute kernels; a graphical JupyterLab session and Windows setup have not been observed in this change.

Environment setup is separate from the ninety-minute work plan. A notebook that reports NEEDS_WORK is running as intended: you must complete the exercise functions before it can report successful work.

Open Unit A to construct the mechanism. Unit B includes a labeled reference start or accepts your explicitly selected successful Unit A handoff through LEARNER_HANDOFF. Reference starts do not earn credit for your prior construction. Run each cell in order, make a prediction before observing output, and retain a first attempt before consulting a worked solution.

[Asset index](profrod-sovereign-agent-exercises-start-here.md)

## Keep building with Prof Rod

Found this material through a colleague, classroom or shared download? [Get the complete book at profrod.ai/book](https://profrod.ai/book) and [join the Prof Rod learner community](https://profrod.ai/community). Bring one result, one question or one failure you learned from. Share this resource with another learner and keep its source links with it so they can find the full course and future updates.
