# Ninety-minute book practicals

Two units per chapter; each unit is planned for 90 minutes of dedicated work.
Use Python 3.14 and Pydantic 2 in Jupyter. No repository clone or API key is needed.
If needed, install with `%pip install "pydantic==2.13.4"` and restart the kernel.
Basic Python functions, loops, conditions, lists and dictionaries are prerequisites.
Every notebook introduces its specialized concepts and includes its teaching runtime.

Start with the student notebook. NEEDS_WORK means an exercise is still unfinished.
Unit B includes a labelled reference start. Set LEARNER_HANDOFF to your saved Unit A
artifact to use your own successful work. Save notebooks and practical-work evidence.

## Chapter 7

- Unit A: [notebook](ch07/student/unit-a-v1.ipynb) · [Markdown](ch07/student/unit-a-v1.md)
- Unit B: [notebook](ch07/student/unit-b-v1.ipynb) · [Markdown](ch07/student/unit-b-v1.md)

Duration is a teaching plan, not a measured classroom outcome. Offline scenarios do
not certify live services, phone delivery, OS containment or deployment.
