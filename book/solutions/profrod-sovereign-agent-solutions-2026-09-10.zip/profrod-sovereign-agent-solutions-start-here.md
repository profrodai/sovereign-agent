# Solutions book

> **Learn with Prof Rod** — *Build Your Always-On AI Agent From Scratch*.
> **Read the full book and get the latest learning materials:** [https://profrod.ai/book](https://profrod.ai/book).
> **Join the Prof Rod learner community:** [https://profrod.ai/community](https://profrod.ai/community)
> — bring your questions, compare experiments and share what you build.
> **Original source and updates:** [profrodai/sovereign-agent](https://github.com/profrodai/sovereign-agent).

Build Your Always-On AI Agent From Scratch · nineteen-chapter edition · 9 September 2026

Study worked implementations and their reasoning after attempting the exercises. Each notebook repeats the required setup and concepts, includes the full exercise context and tests additional cases.

[Set up your environment](profrod-sovereign-agent-solutions-setup.md) · You have the complete asset.

The edition has nineteen chapter slots. **Eighteen chapters currently have two ninety-minute units each: 36 units and 54 hours of available practice. Chapter 13 is a planned construction brief.** The finished plan calls for 38 units and 57 hours; those two additional units are not yet published. Existing units use a supplied runtime and can be studied while the new foundations are authored. No completed notebook is represented by an empty placeholder.

| Chapter | Topic | Availability |
|---|---|---|
| 1 | [What a model call is: tokens, probabilities and Lucy's first brief](ch01/profrod-sovereign-agent-ch01-first-model-call-solutions-guide.md) | Available draft — A and B, 90 minutes each |
| 2 | [Structured output and typed tools: what a schema guarantees](ch02/profrod-sovereign-agent-ch02-pydantic-shop-tools-solutions-guide.md) | Available draft — A and B, 90 minutes each |
| 3 | [The agent loop: why reliability compounds, and a loop that stops](ch03/profrod-sovereign-agent-ch03-agent-loop-solutions-guide.md) | Available draft — A and B, 90 minutes each |
| 4 | [Build durable SQLite state](ch04/profrod-sovereign-agent-ch04-sqlite-state-solutions-guide.md) | Available draft — A and B, 90 minutes each |
| 5 | [Memory and retrieval: what the model sees, and a memory that forgets](ch05/profrod-sovereign-agent-ch05-durable-memory-solutions-guide.md) | Available draft — A and B, 90 minutes each |
| 6 | [In-context learning: why a skill's exact words must be tested](ch06/profrod-sovereign-agent-ch06-versioned-skills-solutions-guide.md) | Available draft — A and B, 90 minutes each |
| 7 | [Build a durable work inbox and report outbox](ch07/profrod-sovereign-agent-ch07-durable-inbox-outbox-solutions-guide.md) | Available draft — A and B, 90 minutes each |
| 8 | [Talk to the agent from your phone](ch08/profrod-sovereign-agent-ch08-telegram-messaging-solutions-guide.md) | Available draft — A and B, 90 minutes each |
| 9 | [Wake up for schedules and stock events](ch09/profrod-sovereign-agent-ch09-schedules-stock-events-solutions-guide.md) | Available draft — A and B, 90 minutes each |
| 10 | [Ask permission before spending](ch10/profrod-sovereign-agent-ch10-spending-permissions-solutions-guide.md) | Available draft — A and B, 90 minutes each |
| 11 | [Survive the ambiguous supplier order](ch11/profrod-sovereign-agent-ch11-ambiguous-supplier-order-solutions-guide.md) | Available draft — A and B, 90 minutes each |
| 12 | [Recover work after a process crash](ch12/profrod-sovereign-agent-ch12-worker-recovery-solutions-guide.md) | Available draft — A and B, 90 minutes each |
| 13 | [Build an MCP client and tool server](ch13/profrod-sovereign-agent-ch13-mcp-tools-solutions-guide.md) | PLANNED — brief only |
| 14 | [Isolate tools and untrusted content](ch14/profrod-sovereign-agent-ch14-tool-isolation-solutions-guide.md) | Available draft — A and B, 90 minutes each |
| 15 | [Evaluation as measurement: error bars and paired comparisons](ch15/profrod-sovereign-agent-ch15-agent-evaluation-solutions-guide.md) | Available draft — A and B, 90 minutes each |
| 16 | [Optimizing against an evaluation: the winner's curse and preferences](ch16/profrod-sovereign-agent-ch16-controlled-improvement-solutions-guide.md) | Available draft — A and B, 90 minutes each |
| 17 | [Delegate one bounded task](ch17/profrod-sovereign-agent-ch17-bounded-delegation-solutions-guide.md) | Available draft — A and B, 90 minutes each |
| 18 | [What a model call costs, and a deployment that survives](ch18/profrod-sovereign-agent-ch18-deployment-restoration-solutions-guide.md) | Available draft — A and B, 90 minutes each |
| 19 | [Lucy leaves the shop for a day](ch19/profrod-sovereign-agent-ch19-integrated-shop-day-solutions-guide.md) | Available draft — A and B, 90 minutes each |

## How to use this asset

Start with the setup page. Choose a chapter, then Unit A followed by Unit B. Keep predictions, source changes, failed attempts and transfer results. Each unit supplies the concepts and runtime it requires; prior specialized-library experience is not assumed. Ninety minutes is a planned dedicated-work allowance, not a measured completion guarantee.

Notebook and Markdown files contain the same cells. Core work runs offline after setup. Live-model, Telegram, container and service-operation observations remain separate from local fixture results. These materials are construction drafts; classroom outcomes and editorial quality still require human review.

## Find and share a file

Every teaching file starts with `profrod-sovereign-agent`, followed by its chapter, topic and role. Search for `ch02` to find Chapter 2 or `pydantic` to find its typed-tool material. For example: `profrod-sovereign-agent-ch02-a-pydantic-shop-tools-solution.ipynb`. The `exercise`, `solution`, `educator-exercise` and `educator-solution` endings distinguish files even when copied into one folder. Keep the original filename and source links when sharing. The matching Markdown uses the same filename with `.md`.

## Keep building with Prof Rod

Found this material through a colleague, classroom or shared download? [Get the complete book at profrod.ai/book](https://profrod.ai/book) and [join the Prof Rod learner community](https://profrod.ai/community). Bring one result, one question or one failure you learned from. Share this resource with another learner and keep its source links with it so they can find the full course and future updates.
